public class Attribute1 {
    int x=10;
    public static void main(String[]args){
        Attribute1 myObj= new Attribute1();
        myObj.x=25;//x is now 25
        System.out.println(myObj.x);
    }
}
