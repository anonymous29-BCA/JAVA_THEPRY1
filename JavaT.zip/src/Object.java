public class Object {
    int x = 5;
    public static void main(String[] args) {
        Object myObj = new Object();
        System.out.println(myObj.x);
    }
}
